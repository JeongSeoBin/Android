package com.example.dialogex2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String[] versions = {"오레오","파이","큐"};
                final boolean[] check = {true,false,false};

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("제목입니다");
                builder.setIcon(R.mipmap.ic_launcher);
                //목록출력
                /*builder.setItems(versions, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        btn.setText(versions[i]);
                    }
                });*/
                //라디오버튼 출력
                /*builder.setSingleChoiceItems(versions, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        btn.setText(versions[i]);
                    }
                });*/
                //체크박스 출력
                builder.setMultiChoiceItems(versions, check, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                        btn.setText(versions[i]);
                    }
                });

                builder.setPositiveButton("닫ㄱㅣ",null);
                builder.show();
            }
        });
    }
}
