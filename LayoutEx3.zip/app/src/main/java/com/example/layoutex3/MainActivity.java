package com.example.layoutex3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView iv;
    int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv=findViewById(R.id.iv);
    }

    private void loadImage(int id){
        //프로그램 실행 중에 이미지를 읽어 온다
        //이미지 리소스(res 폴더와 하위폴더 전체)에 있으므로 Resource 객체에 얻어 온다
        //getResources() : 리소스 객체를 얻어 온다
        Resources resources = getResources();

        //Resources 객체에서 이미지를 읽어서 BitmapDrawable 객체에 저장시킨다
        //getDrawable() : 인수로 지정된 이미지(이미지의 id)를 Resources 객체(res 폴더)에서 얻어 온다
        BitmapDrawable bitmapDrawable = (BitmapDrawable) resources.getDrawable(id);

        //ImageView 객체에 Resources 객체에서 읽어서 BitmapDrawable 객체에 저장한 이미지를 넣어 준다
        //setImageDrawable() : ImageView에 이미지를 넣어 준다
        iv.setImageDrawable(bitmapDrawable);

        //getIntrinsicWidth() : 원래 이미지의 폭
        //getIntrinsicHeight() : 원래 이미지의 높이
        Toast.makeText(getApplicationContext(), bitmapDrawable.getIntrinsicWidth() + "*" + bitmapDrawable.getIntrinsicHeight(), Toast.LENGTH_SHORT).show();
    }

    public void chageImage(View view) {
        int id = 0;
        switch(index++ % 3){
            case 0:
                id = R.drawable.image1;
                break;
            case 1:
                id = R.drawable.image2;
                break;
            case 2:
                id = R.drawable.image3;
                break;
        }
        loadImage(id);
    }
}
