package com.example.layoutex2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView[] imageViews = new ImageView[4];
    int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //FrameLayout에 겹쳐진 모든 이미지들을 배열에 담는다
        //위젯의 아이다 값들은 1씩 증가한다
        for(int i = 0; i<imageViews.length; i++){
            imageViews[i] = findViewById(R.id.iv1 + i);
        }
    }

    public void changeImage(View view) {
        //FrameLayout의 모든 이미지를 숨긴다
        for(int i = 0; i<imageViews.length; i++){
            imageViews[i].setVisibility(View.INVISIBLE);
        }

        //표시할 이미지만 FrameLayout에 표시한다
        imageViews[++index % imageViews.length].setVisibility(View.VISIBLE);
    }
}
