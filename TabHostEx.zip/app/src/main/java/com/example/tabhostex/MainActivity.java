package com.example.tabhostex;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TabActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TabHost;

/*
* TabActivity를 상속받는다
* 탭스펙을 생성한다 ( 텝스펙 : 탭을 구성하는 요소들의 집합)
* 탭스펙 생성시 Indicator와 content를 set한다
* 생성한 탭스펙을 tabHost에 추가한다
* */
public class MainActivity extends TabActivity {
    LinearLayout tabSong,tabArtist,tabAlbum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabSong = findViewById(R.id.tabSong);
        tabArtist = findViewById(R.id.tabArtist);
        tabAlbum = findViewById(R.id.tabAlbum);

        //탭호스트 객체 샹성
        TabHost tabHost = getTabHost();

        //탭스펙을 생성한다 ( 텝스펙 : 탭을 구성하는 요소들의 집합)
        //탭스펙 생성시 Indicator와 content를 set한다
        TabHost.TabSpec tabSpec1 = tabHost.newTabSpec("song").setIndicator("음악별");
        tabSpec1.setContent(R.id.tabSong);
        //생성한 탭스펙을 tabHost에 추가한다
        tabHost.addTab(tabSpec1);

        TabHost.TabSpec tabSpec2 = tabHost.newTabSpec("artist").setIndicator("가수별");
        tabSpec2.setContent(R.id.tabArtist);
        tabHost.addTab(tabSpec2);

        TabHost.TabSpec tabSpec3 = tabHost.newTabSpec("album").setIndicator("앨범별");
        tabSpec3.setContent(R.id.tabAlbum);
        tabHost.addTab(tabSpec3);

        tabHost.setCurrentTab(0);
    }
}
