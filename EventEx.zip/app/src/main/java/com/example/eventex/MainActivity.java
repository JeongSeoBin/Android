package com.example.eventex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv;
    //onTouchEvent() 메소드가 실행할 기능을 위임받을 GestureDetector 클래스 객체를 선언한다
    GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tv);

        //onTouchEvent() 메소드가 실행할 기능을 위임받을 GestureDetector 클래스 객체를 생성한다
        //위임받은 TouchEvent를 처리할 GestureDetector 객체를 생성하고 SimpleOnGestureListener 클래스의 메소드 중에서 필요한 메소드를 override해서 TouchEvent를 처리한다
        gestureDetector = new GestureDetector(new GestureDetector.SimpleOnGestureListener(){
            //스크린을 손가락으로 한번 눌렀다 뗄 경우 실행 => 클릭
            //터치를 길게 해서 onLongPress(0 메소드로 제어가 넘어가면 실행되지 않는다
            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                tv.append("onSingleTapUp()\n");
                return super.onSingleTapUp(e);
            }

            //스크린에 터치가 감지되고 스크린을 길게 누르고 있을 때 실행되는 메소드
            @Override
            public void onLongPress(MotionEvent e) {
                super.onLongPress(e);
                tv.append("onLongPress()\n");
            }

            //스크린을 짧게 터치한 상태로 일정한 속도와 방향으로 움직일 경우 실행되는 메소드
            //터치를 길게 해서 onLongPress() 메소드로 제어가 넘어가면 실행안된다
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                tv.append("onPress()" + distanceX + "," + distanceY + "\n");
                return super.onScroll(e1, e2, distanceX, distanceY);
            }

            //스크린을 짥게 터치한 상태로 가속도를 붙여 손가락을 움직였을 때 실행되는 메소드
            //터치를 길게 해서 onLongPress() 메소드로 제어가 넘어가면 실행되지 않는다
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                tv.append("onFling()" + velocityX + "," + velocityY +"\n");
                return super.onFling(e1, e2, velocityX, velocityY);
            }

            //스크린에 터치가 감지되고 스크린을 짧게 누르고 있을 때 실행되는 메소드
            //클릭만 하면 실행안된다
            @Override
            public void onShowPress(MotionEvent e) {
                super.onShowPress(e);
                tv.append("onShowPress()\n");
            }

            //스크린에 터치가 감지되면 실행되는 메소드
            @Override
            public boolean onDown(MotionEvent e) {
                tv.append("onDown()\n");
                return super.onDown(e);
            }

            //스크린을 손가락으로 연속해서 두번 눌렀다 뗄 겨우 실향 => 더블클릭
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                tv.append("onDoubleTap\n");
                return super.onDoubleTap(e);
            }

            //스크린을 연속해서 두번 눌렀다 뗼 경우 실행
            //onDoubleTap() 메소드 실행되고 난 후 실행
            @Override
            public boolean onDoubleTapEvent(MotionEvent e) {
                tv.append("onDoubleTapEvent\n");
                return super.onDoubleTapEvent(e);
            }

            //스크린을 손가락으로 한번 눌렀다 뗼 경우 실행
            //OnSingleTapUp(0 메소드가 실행되고 난 후 실행
            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                tv.append("onSingleTapConfirmed()\n");
                return super.onSingleTapConfirmed(e);
            }

            @Override
            public boolean onContextClick(MotionEvent e) {
                return super.onContextClick(e);
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(gestureDetector != null){
            //스트린이 터치되면 자동으로 실행되는 onTouchEvent()가 실행할 기능을 GestureDetector 객체로 위임한다
            return gestureDetector.onTouchEvent(event);
        }
        return super.onTouchEvent(event);
    }
}
