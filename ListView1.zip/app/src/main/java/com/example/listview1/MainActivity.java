package com.example.listview1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    String[] datas = { "김일승", "김이승", "김삼승", "김사승", "김오승", "김육승", "김칠승", "김팔승", "김구승", "김십승",
            "김일순", "김이순", "김삼순", "김사순", "김오순", "김육순", "김칠순", "김팔순", "김구순", "김십순",
            "김일자", "김이자", "김삼자", "김사자", "김오자", "김육자", "김칠자", "김팔자", "김구자", "김십자"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView  = findViewById(R.id.listView);

        //ListView에 데이터를 넣으려면 반드시 Adapter를 이용해서 데이터를 할당해야한다
        //배열(Array)이나 ArrayList와 같은 List 데이터(간단한 데이터, 일차원 데이터)는 안드로이드에서 제공하는 ArrayAdapter를 시용한다
        //new ArrayAdapter<>(ListView가 표시되는 액티비티, 레이아웃, ListView에 표시할 데이터)
       // ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,datas);

        /*
        //배열이나 ArrayList에 저장된 데이터와 라디오 버튼을 ListView에 표시한다
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_single_choice,datas);
        //위와 같이 코딩하면 ListView에 라디오 버튼은 표시되지만 선택이 안되기 때문에 ChoiceMode를 지정해야한다
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        */

        //배열이나 ArrayList에 저장된 데이터와 체크박스를 ListView에 표시한다
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_multiple_choice,datas);
        //위와 같이 코딩하면 ListView에 체크박스가 표시되지만 선택이 안되기 떄문에 ChoiceMode를 지정해야한다
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

       /*//배열이나 ArrayList에 저장된 데이터와 체크를 ListView에 표시한다
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_checked,datas);
        //위와 같이 코딩하면 ListView에 체크는 표시되지만 선택이 안되기 때문에 ChoiceMode를 지정해야한다
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);*/

        //ListView에 데이터를 넣어준다
        listView.setAdapter(adapter);

        //ListView를 짧게 클릭했을때 실행햐야할 동작이 있다면 ItemClickListener를 걸어준다
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),position + 1 + "번째 데이터" + datas[position] + "선택", Toast.LENGTH_SHORT).show();
            }
        });

        //ListView를 길게 클릭했늘때 실행해야 할 동작이 있다면 ItemLongClickListener를 걸어준다
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                Toast.makeText(getApplicationContext(),position + 1 + "번째 데이터를 길게 클릭",Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }
}
