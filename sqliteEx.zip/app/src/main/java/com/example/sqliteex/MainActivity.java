package com.example.sqliteex;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView idTV;
    EditText nameET, ageET;
    Button saveBtn, updateBtn;
    ListView listView;
    SQLiteDatabase db;
    List<String> list = new ArrayList<>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idTV = (TextView) findViewById(R.id.idTV);
        nameET = (EditText) findViewById(R.id.nameET);
        ageET = (EditText) findViewById(R.id.ageET);
        saveBtn = (Button) findViewById(R.id.saveBtn);
        updateBtn = (Button) findViewById(R.id.updateBtn);
        //한정된 화면에서 많은 데이터를 표기할 수 있는 방법
        listView = (ListView) findViewById(R.id.listView1);

        // 처음에 업데이트 버튼은 누룰수 없다.
        updateBtn.setEnabled(false);

        //데이터 베이스를 만들거나 열거나
        db = openOrCreateDatabase("addr.db", MODE_PRIVATE, null);

        // 테이블을 생성
        try {
            //SQL 명령어 만들기
            //StringBuffer는 String과 같이 문자열을 처리한다
            //둘의 차이점은 String은 immutable이고 StringBuffer는 mutable이다
            StringBuffer sb = new StringBuffer();
            sb.append("create table addr (");
            sb.append("_id integer primary key,");
            sb.append("name nvarchar2(50) not null,");
            sb.append("age integer default 0)");
            //명령어 실행하기
            //execSQL() : select 문이 아닌 나머지 sql 문 실행
            db.execSQL(sb.toString());
            Log.e("Sqlite", "테이블 생성 성공");
        } catch (Exception e) {
            Log.e("Sqlite", "테이블이 이미 존재합니다.");
        }

        //데이터를 조회해서 ArrayList에 추가한다
        selectAll();
        //ArrayAdapter : ArrayList를 받아서 ListView에 장착
        adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
        //데이터가 변경되었음을 알려 준다
        adapter.notifyDataSetChanged();

        //리스트 뷰를 클릭하면 선택한 놈을 수정가능하도록 에디트 텍스트에 뿌려 주고
        //저장하기 버튼은 비활성화 수정하기 버튼은 활성화
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    //i는 listView 내에서 클릭한 position
                    //Log.d("i",i +"");
                    //점을 기준으로 글 번호를 가져 온다
                    //listView에서 선택한 아이템에 해당하는 문자열을 list에서 가져와서 점을 기준으로 자른다
                    int idx = Integer.parseInt(list.get(i).split("\\.")[0]);
                    //Toast.makeText(getApplicationContext(), idx + "번", Toast.LENGTH_SHORT).show();

                    //테이블에서 글 번호에 해당하는 한 행을 얻어 온다
                    String sql = "select * from addr where _id =" + idx;
                    Cursor cursor = db.rawQuery(sql, null);
                    //Log.d("Addr", cursor.getCount() + "개");

                    if (cursor.moveToNext()) {
                        //얻어 온 글 번호에 해당하는 행의 각각의 열을 얻어 온다
                        //열에 해당하는 id name age를 수정할 수 있게 editText에 set한다
                        idTV.setText(cursor.getInt(0) + "");
                        nameET.setText(cursor.getString(1));
                        ageET.setText(cursor.getInt(2) + "");

                        //저장하기 버튼은 비활성화 수정하기 버튼은 활성화
                        saveBtn.setEnabled(false);
                        updateBtn.setEnabled(true);
                    } else {
                        Log.d("Addr", idx + "글번호 읽기 실패");
                    }
                }catch(Exception e){
                    Log.d("Addr","글번호 읽기 실패");
                }
            }
        });

        //리스트 뷰의 항목을 길게 클릭하면 삭제 대화상자를 열어 확인하고 삭제한다
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                //롱 클릭 이벤트 작동 확인
                Toast.makeText(getApplicationContext(),i + "번 선택",Toast.LENGTH_SHORT).show();
                try{
                    //글 번호를 알아야 한다
                    final int idx = Integer.parseInt(list.get(i).split("\\.")[0]);

                    //삭제 여부를 물어 보는 대화상자를 띄운다
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("삭제확인");
                    builder.setMessage("정말로 삭제하시겠습니까?");
                    builder.setIcon(android.R.drawable.ic_delete);

                    builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //대화상자에서 "예"버튼을 클릭하면 글 번호에 해당하는 행을 삭제한다
                            String sql = "delete from addr where _id =" + idx;
                            db.execSQL(sql);

                            //지운 것만 리스트에서 삭제하고 리스트뷰를 갱신하면서 다시 db를 읽어 올 필요없다
                            list.remove(i);
                            //리스트 뷰 갱신
                            adapter.notifyDataSetChanged();

                            //입력창 리셋하기
                            nameET.setText("");
                            ageET.setText("");
                            idTV.setText("");

                            //수정하기 버튼 비활성화
                            updateBtn.setEnabled(false);
                            //저장하기 버튼 활성화
                            saveBtn.setEnabled(true);
                        }
                    });
                    builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //입력창 지우기
                            nameET.setText("");
                            ageET.setText("");
                            idTV.setText("");

                            //수정하기 버튼 비활성화
                            updateBtn.setEnabled(false);
                            //저장하기 버튼 활성화
                            saveBtn.setEnabled(true);
                        }
                    });

                    AlertDialog dialog = builder.create();
                    dialog.show();

                    Log.d("Addr","삭제성공");
                }catch(Exception e){
                    Log.d("Addr","삭제 실패");
                }
                return false;
            }
        });

    }

    private void selectAll(){
        //리스트의 모든 내용을 지운다
        list.clear();
        String sql = "select * from addr order by _id desc";
        //rawQuery() : select sql 문 실행
        //cursor : 행의 집합객체
        Cursor cursor = db.rawQuery(sql,null);
        //moveToNext() : 행을 선택한다
        if(cursor.moveToNext()){
            do{
                //get**() : 열을 선택한다
                int idx = cursor.getInt(0);
                String name = cursor.getString(1);
                int age = cursor.getInt(2);
                list.add(idx + ". " + name + "(" + age + "세)\n");
            }while(cursor.moveToNext());
        }else{
            list.add("데이터가 없습니다");
        }
    }

    public void saveAddr(View view) {
        try{
            //입력창에 입력한 name과 age를 얻어 온다
            String name = nameET.getText().toString();
            int age = Integer.parseInt(ageET.getText().toString());

            if(name != null && name.trim().length() > 0 && age > 0){
                //입력창에 입력한 name과 age를 테이블에 저장한다
                //sql 명령어 만들기
                StringBuffer sb = new StringBuffer();
                sb.append("insert into addr (name,age) values (");
                sb.append("'" + name + "'," + age + ")");
                //명령어 실행하기
                db.execSQL(sb.toString());

                //데이터 다시읽기
                selectAll();
                //데이터가 변경되었음을 알려야 한다
                adapter.notifyDataSetChanged();

                //입력창을 리셋한다
                nameET.setText("");
                ageET.setText("");
            }
        }catch(Exception e){
            Log.d("Addr","저장 실패!!!!");
        }
    }

    public void updateAddr(View view) {
        try{
            //입력창에서 수정한 id name age를 얻어 온디
            int id = Integer.parseInt(idTV.getText().toString());
            String name = nameET.getText().toString();
            int age = Integer.parseInt(ageET.getText().toString());

            if(name != null && name.trim().length() > 0 && age > 0) {
                //입력창에서 수정한 내용으로 update한다
                // SQL 명령어 만들기
                StringBuffer sb = new StringBuffer();
                sb.append("update addr set ");
                sb.append(" name='" + name + "',age=" + age);
                sb.append(" where _id=" + id);
                // 명령어 실행하기
                db.execSQL(sb.toString());

                // 데이터 다시읽기
                selectAll();
                // 리스트 뷰 갱신
                adapter.notifyDataSetChanged();

                // 수정 완료 후 입력창 지우기
                nameET.setText("");
                ageET.setText("");
                idTV.setText("");

                // 수정하기 버튼 비활성화 저장하기 버튼 활성화
                updateBtn.setEnabled(false);
                saveBtn.setEnabled(true);
                Log.d("Addr", "수정 성공!!!!");
            }
        }catch(Exception e){
                Log.d("Addr", "수정 실패!!!!");
        }
    }
}