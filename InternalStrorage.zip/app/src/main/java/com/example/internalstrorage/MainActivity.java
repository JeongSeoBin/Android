package com.example.internalstrorage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
    Button btnRead,btnWrite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnRead = findViewById(R.id.btnRead);
        btnWrite = findViewById(R.id.btnWrite);

        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    //파일열기
                    FileOutputStream outputStream = openFileOutput("file.txt", Context.MODE_PRIVATE);
                    //파일쓰기
                    String str = "안드로이드";
                    outputStream.write(str.getBytes());
                    //파일닫기
                    outputStream.close();
                    Toast.makeText(getApplicationContext(),"file,txt가 생성됨",Toast.LENGTH_SHORT).show();
                }catch(Exception e){ }
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //파일열기
                    FileInputStream inputStream = openFileInput("file.txt");
                    //파일읽기
                    byte[] txt = new byte[30];
                    inputStream.read(txt);
                    String str = new String(txt);
                    Toast.makeText(getApplicationContext(),str,Toast.LENGTH_SHORT).show();
                    inputStream.close();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(),"파일 없음",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
