package com.example.firstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //레이아웃에서 설정한 id를 지정한 위젯을 기억하는 객체(변수)를 선언한다
    TextView tv,tv2;
    Button btn,btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //레이아웃에서 설정한 id에 해당되는 위젯을 찾아서 변수에 저장시킨다
        tv = findViewById(R.id.tv);
        tv2 = findViewById(R.id.tv2);

        //레이아웃 설정시 사용하는 android:autoLink를 사용하지 않고 엑티비티에서 TextView에 자동연결 설정하기
        //Linkify.addLinks(TextView객체, Linlify.연결방식)
        //Linkify.EMAIL_ADDRESSES : 이메일
        Linkify.addLinks(tv, Linkify.WEB_URLS);//인터넷
        Linkify.addLinks(tv2,Linkify.PHONE_NUMBERS);//전화걸기

        btn=findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast는 스크린에 간단한 메시지를 출력한다
                //makeText(Toast가 표시될 액티비티, 메시지, Toast 메시지 표시시간).show
                Toast.makeText(getApplicationContext(),"안드로이드",Toast.LENGTH_SHORT).show();
            }
        });

        btn2 = findViewById(R.id.btn2);
    }

    public void callPhone(View view) {
        Toast.makeText(getApplicationContext(),"전화걸기",Toast.LENGTH_SHORT).show();
        //안드로이드에서 Intent는 무엇인가 하고자하는 행위를 의미한다
        //Intent를 통해 애플리케이션의 구성요소들간에 데이터를 전달하거나 실행하기 위한 기능이 무엇인지 안드로이드 시스템에게 알려 줄 수 있다
        //Intent.ACTION_VIEW => 새 액티비티를 띄운다

        //전화걸기
        //Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:031-1234-5678"));
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:031-1234-5678"));

        //startActivity() 메소드는 Intent객체 정보를 바탕으로 새 액티비티를 실행한다
        startActivity(intent);
    }

    public void gotoNaver(View view) {
        Toast.makeText(getApplicationContext(),"네이버로 이동",Toast.LENGTH_SHORT).show();
        //웹 페이지 띄우기
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.naver.com"));

        // 구글맵 띄우기
        //Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:16.03413005,108.22488053"));

        startActivity(intent);
    }
}
