package com.example.sdcard_readfile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
//MP3파일처럼 여러 응용프로그램에서 사용되는 경우 SD 카드에 저장해 활용
//sd카드를 사용할 수 있도록 허용
//AndroidManifest.xml에 <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>추가
//<application>에 android:requestLegacyExternalStorage="true" 추가

public class MainActivity extends AppCompatActivity {
    EditText et;
    Button read;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et = findViewById(R.id.et);
        read = findViewById(R.id.read);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},MODE_PRIVATE);

        //sd 카드에서 파일읽기
        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    FileInputStream inputStream = new FileInputStream("/sdcard/text.txt");
                    byte[] txt = new byte[inputStream.available()];
                    inputStream.read(txt);
                    et.setText(new String(txt));
                    inputStream.close();
                } catch (Exception e) { }
            }
        });
    }
}
