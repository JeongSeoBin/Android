package com.example.rawfolder_readfile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.io.InputStream;
//res 폴더 아래 raw 폴더에 필요한 파일을 저장해서 사용
//raw 폴더는 프로젝트에 포함된 폴더이므로 읽기만 가능
public class MainActivity extends AppCompatActivity {
    EditText et;
    Button read;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et = findViewById(R.id.et);
        read = findViewById(R.id.read);

        //raw 폴더에 있는 파일을 읽어 온다
        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    InputStream inputStream = getResources().openRawResource(R.raw.text);
                    byte[] txt = new byte[inputStream.available()];
                    inputStream.read(txt);
                    et.setText(new String(txt));
                    inputStream.close();
                } catch (Exception e) {  }
            }
        });
    }
}
