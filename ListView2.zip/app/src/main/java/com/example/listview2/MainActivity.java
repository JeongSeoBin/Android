package com.example.listview2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<HashMap<String,String>> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);

        //데이터를 만든다
        for(int i = 0; i < 30; i++){
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("name", "사람" + (i+1));
            hashMap.put("age", new Random().nextInt(100) + 1 + "세");
            list.add(hashMap);
        }

        //한개짜리 데이터를 ListView에 추가할때는 안드이드에서 제공하는 ArrayAdapter를 사용했지만
        //두개짜리 데이터를 ListView에 추가할때는 SimpleAdapter를 사용한다
        //new SimoleAdapter(ListView가 표시될 액티비티,데이터,레이아웃,데이터순서(키),데이터순서(일련번호))
        SimpleAdapter simpleAdapter = new SimpleAdapter(getApplicationContext(),list,android.R.layout.simple_expandable_list_item_2,new String[]{"name","age"},new int[]{android.R.id.text1,android.R.id.text2});
        listView.setAdapter(simpleAdapter);
    }
}
