package com.example.autocompletetest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {
    MultiAutoCompleteTextView mactv;
    AutoCompleteTextView actv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mactv = findViewById(R.id.mactv);
        actv = findViewById(R.id.actv);

        //자동완성 텍스트로 뜰 텍스트들을 배열로 저장한다
        String[] items = {"CSI-뉴욕","CSI-라스베가스","CSI-마이애미","Friends","Fringe","Lost"};
        //사용자가 지정한 자동완성텍스트 배열이 자동완성 텍스트로 나오도록 연결
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,items);

        actv.setAdapter(adapter);

        //단어들을 ","로 구분할 수 있게 한다
        MultiAutoCompleteTextView.CommaTokenizer tokenizer = new MultiAutoCompleteTextView.CommaTokenizer();
        mactv.setTokenizer(tokenizer);
        mactv.setAdapter(adapter);
    }
}
