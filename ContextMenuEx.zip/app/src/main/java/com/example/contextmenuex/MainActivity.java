package com.example.contextmenuex;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
//contextMenu
//레이아웃 또는 위젯을 롱클릭하면 나타남

public class MainActivity extends AppCompatActivity {
    LinearLayout base;
    Button btn1,btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        base = findViewById(R.id.base);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);

        //메뉴에 사용할 위젯을 등록한다
        registerForContextMenu(btn1);
        registerForContextMenu(btn2);
    }

    //위젯을 롱클릭하면 contextMenu가 만들어 진다
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater menuInflater = getMenuInflater();
        //롱클릭한 위젯이 btn1일때
        if(v == btn1){
            //해당 메뉴파일을 등록
            menu.setHeaderTitle("배경색 변경");
            menuInflater.inflate(R.menu.menu1,menu);
        }
        //롱클릭한 위젯이 btn2일때
        if(v == btn2){
            //해당 메뉴파일을 등록
            menu.setHeaderTitle("버튼 변경");
            menuInflater.inflate(R.menu.menu2,menu);
        }
    }

    //메뉴 선택시 작동할 내용

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.red:
                base.setBackgroundColor(Color.RED);
                return true;
            case R.id.blue:
                base.setBackgroundColor(Color.BLUE);
                return true;
            case R.id.green:
                base.setBackgroundColor(Color.GREEN);
                return true;
            case R.id.rotate:
                btn2.setRotation(45);
                return true;
            case R.id.size:
                btn2.setScaleX(2);
                return true;
        }
        return super.onContextItemSelected(item);
    }
}
