package com.example.datasendtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main5Activity extends AppCompatActivity {
    TextView tv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        tv2 = findViewById(R.id.tv2);

        Intent intent = getIntent();
        //getParcelableExtra() : Parcelable 인터페이스를 구현받아 직렬화된 클래스 객체를 받는다
        //getParcelableExtra() 메소드는 Parcelable 인터페이스를 구현받은 객체를 Serializable 인터페이스를 구현해 직렬화된 객체를 받을 때처럼
        //형변환시키지 않아도 정상적으로 처리된다 => Parcelable 인터페이스로 직렬화하는 것을 권장한다
        SimpleData simpleData = intent.getParcelableExtra("simpleData");

        String str =  simpleData.getName() + "(" + simpleData.getAge() + ", " + (simpleData.isGerder() ? "남" : "여") + ")";
        tv2.setText(str);
    }

    public void goback(View view) {
        finish();
    }
}
