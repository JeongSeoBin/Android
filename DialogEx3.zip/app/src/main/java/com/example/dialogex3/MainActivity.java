package com.example.dialogex3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView name,email;
    Button btn;
    EditText dlgEt1,dlgEt2;
    TextView toastTv;
    View dialogView,toastView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                builder.setTitle("사용자 정보 입력");
                builder.setIcon(R.drawable.ic_launcher_background);

                //대화상자에 별도의 view(layout)을 지정할 수 있다
                //inflater로 layout 파일을 전개하여 대화상자에 지정할 view를 만든다
                dialogView = View.inflate(MainActivity.this, R.layout.dialog1,null);
                builder.setView(dialogView);

                //editText에 입력한 내용이 대화상자의 EditText에 입력하게 한다
                //dialog1 파일에 있는 위젯의 id를 가져올 때는 해당 파일을 전개한 view 객체의 findViewById()를 이용한다
                dlgEt1 = dialogView.findViewById(R.id.dlgEt1);
                dlgEt2 = dialogView.findViewById(R.id.dlgEt2);
                dlgEt1.setText(name.getText().toString());
                dlgEt2.setText(email.getText().toString());

                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //대화상자에 입력한 내용을 메인화면에 있는 EditText에 입력되게 한다
                        name.setText(dlgEt1.getText().toString());
                        email.setText(dlgEt2.getText().toString());
                    }
                });
                builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast toast = new Toast(MainActivity.this);

                        toastView = View.inflate(MainActivity.this,R.layout.toast1,null);
                        toastTv = toastView.findViewById(R.id.toastTv);
                        toastTv.setText("취소했습니다");
                        toast.setView(toastView);

                        toast.show();
                    }
                });
                builder.show();
            }
        });
    }
}
