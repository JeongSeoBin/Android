package com.example.radiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    CheckBox check;
    TextView tv;
    RadioButton radio1,radio2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        check = findViewById(R.id.check);
        radio1 = findViewById(R.id.radio1);
        radio2 = findViewById(R.id.radio2);
        tv = findViewById(R.id.tv);
    }

    public void selectCheckBox(View view) {
        //isChecked() : RadionButton이나 CheckBox가 선택되면 true, 해제 상태면 false
        //setChecked() : RadionButton이나 CheckBox를 선택(true), 해제(false)시킨다
        check.setChecked(check.isChecked()?false:true);
    }

    public void viewResult(View view) {
        String str = (radio1.isChecked()?"남자":"여자") + "는 " + (check.isChecked()?"하루종일":"반나절") + "일을 합니다";

        //setText() : TextView에 문자열을 넣어 준다 (기존에 입력된 문자열을 지운다)
        //append() : TextView에 문자열을 넣어 준다 (기존에 입력한 문자열 뒤에 추가한다)
        tv.setText(str);
        tv.append(str);
    }
}
