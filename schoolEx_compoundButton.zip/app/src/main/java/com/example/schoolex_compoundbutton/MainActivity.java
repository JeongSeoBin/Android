package com.example.schoolex_compoundbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox android,iphone;
    RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        android = findViewById(R.id.android);
        iphone = findViewById(R.id.iphone);
        rg = findViewById(R.id.rg);

        android.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Toast.makeText(getApplicationContext(),android + "를 선택하셨습니다",Toast.LENGTH_SHORT).show();
            }
        });
        iphone.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Toast.makeText(getApplicationContext(),iphone + "을 선택하셨습니다",Toast.LENGTH_SHORT).show();
            }
        });

        //RadioGroup 내에서 check된 RadioButton의 아이디를 가져 온다
        int id = rg.getCheckedRadioButtonId();
    }
}
