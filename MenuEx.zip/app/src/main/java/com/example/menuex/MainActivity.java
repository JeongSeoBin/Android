
package com.example.menuex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;

public class MainActivity extends AppCompatActivity {
    Button btn1,btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);

        //onCreate() 에서 버튼을 짧게 누르면 나타나는 메뉴인 popup 메뉴를 액티비티 화면에 표시한다
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //popup 메뉴를 액티비티에 화면에 표시하기 위해서 PopupMenu 클래스 객체를 생성
                PopupMenu popupMenu = new PopupMenu(getApplicationContext(),view);
                //popup 메뉴를 화면에 전개하기 위해서 MenuInflater 클래스 객체를 생성
                MenuInflater menuInflater = popupMenu.getMenuInflater();

                //메뉴로 표시할 내용이 작성된 xml 파일을 읽어서 전개한다
                //메뉴를 정의하는 xml 파일 만들기
                //: res 폴더에 menu 라는 이름의 폴더를 만들고 메뉴로 표시할 내용이 작성된 xml 파일을 만든다.
                //  menu 폴더 : res 폴더 우클릭 => New => Directory => menu 입력
                //  menu 설정 xml 파일 만들기 : menu 폴더 우클릭 => New => Menu resource file
                menuInflater.inflate(R.menu.menu, popupMenu.getMenu());

                //popup 메뉴를 액티비티 화면에 표시한다
                popupMenu.show();
            }
        });
    }
}
