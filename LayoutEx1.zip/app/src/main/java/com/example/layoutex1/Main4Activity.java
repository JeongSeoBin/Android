package com.example.layoutex1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main4Activity extends AppCompatActivity {
    //레이아웃에서 id를 지정한 위젯 제어에 사용할 객체를 선언한다
    EditText et1,et2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        //제어할 위젯을 찾아서 객체에 대입한다
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
    }

    public void viewData(View view) {
        String id = String.valueOf(et1.getText());
        String pw = String.format("%s",et2.getText());
        Toast.makeText(getApplicationContext(),id + "(" + pw + ")",Toast.LENGTH_SHORT).show();

        et1.setText("");
        et2.setText("");

        //아이디를 입력하는 EditText로 focus를 옮겨 준다
        et1.requestFocus();
    }

    public void goback(View view) {
        finish();
    }
}
