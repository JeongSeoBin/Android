package com.example.animationtest2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnSequence,btnFadeIn,btnFadeOut,btnCrassFade,btnBlink,btnZoomIn,btnZoomOut,btnRotate,btnMove,btnSlideUp,btnSlideDown;
    TextView tvSequence,tvFadeIn,tvFadeOut,tvCrossFadeIn,tvCrossFadOut,tvBlink,tvZoomIn,tvZoomOut,tvRotate,tvMove,tvSlideUp,tvSlideDown;
    Animation sequence,fadeIn,fadeOut,blink,zoomIn,zoomOut,rotate,move,slideUp,slideDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //sequence
        btnSequence = findViewById(R.id.btnSequence);
        tvSequence = findViewById(R.id.tvSequence);
        sequence = AnimationUtils.loadAnimation(this, R.anim.sequence);
        btnSequence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvSequence.startAnimation(sequence);
            }
        });

        //fadeIn
        btnFadeIn = findViewById(R.id.btnFadeIn);
        tvFadeIn  = findViewById(R.id.tvFadeIn);
        fadeIn = AnimationUtils.loadAnimation(this,R.anim.fadein);
        btnFadeIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvFadeIn.startAnimation(fadeIn);
            }
        });

        //fadeOut
        btnFadeOut = findViewById(R.id.btnFadeOut);
        tvFadeOut = findViewById(R.id.tvFadeOut);
        fadeOut = AnimationUtils.loadAnimation(this,R.anim.fadeout);
        btnFadeOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvFadeOut.startAnimation(fadeOut);
            }
        });

        //crossFade
        btnCrassFade = findViewById(R.id.btnCrossFade);
        tvCrossFadeIn = findViewById(R.id.tvCrossFadeIn);
        tvCrossFadOut = findViewById(R.id.tvCrossFadeOut);
        btnCrassFade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvCrossFadeIn.startAnimation(fadeIn);
                tvCrossFadOut.startAnimation(fadeOut);
            }
        });

        //blink
        btnBlink = findViewById(R.id.btnBlink);
        tvBlink = findViewById(R.id.tvBlink);
        blink = AnimationUtils.loadAnimation(this,R.anim.blink);
        btnBlink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvBlink.startAnimation(blink);
            }
        });

        //zoomIn
        btnZoomIn = findViewById(R.id.btnZoomIn);
        tvZoomIn = findViewById(R.id.tvZoomIn);
        zoomIn = AnimationUtils.loadAnimation(this,R.anim.zoomin);
        btnZoomIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvZoomIn.startAnimation(zoomIn);
            }
        });

        //zoomOut
        btnZoomOut = findViewById(R.id.btnZoomOut);
        tvZoomOut = findViewById(R.id.tvZoomOut);
        zoomOut = AnimationUtils.loadAnimation(this, R.anim.zoomout);
        btnZoomOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvZoomOut.startAnimation(zoomOut);
            }
        });

        //rotate
        btnRotate = findViewById(R.id.btnRotate);
        tvRotate = findViewById(R.id.tvRotate);
        rotate = AnimationUtils.loadAnimation(this,R.anim.rotate);
        btnRotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvRotate.startAnimation(rotate);
            }
        });

        //move
        btnMove = findViewById(R.id.btnMove);
        tvMove = findViewById(R.id.tvMove);
        move = AnimationUtils.loadAnimation(this,R.anim.move);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvMove.startAnimation(move);
            }
        });

        //slideUp
        btnSlideUp = findViewById(R.id.btnSlideUp);
        tvSlideUp = findViewById(R.id.tvSlideUp);
        slideUp = AnimationUtils.loadAnimation(this,R.anim.slideup);
        btnSlideUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvSlideUp.startAnimation(slideUp);
            }
        });

        //slideDown
        btnSlideDown = findViewById(R.id.btnSlideDown);
        tvSlideDown = findViewById(R.id.tvSlideDown);
        slideDown = AnimationUtils.loadAnimation(this,R.anim.slidedown);
        btnSlideDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvSlideDown.startAnimation(slideDown);
            }
        });
    }
}
