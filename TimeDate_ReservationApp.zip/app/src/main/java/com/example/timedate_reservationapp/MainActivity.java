package com.example.timedate_reservationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.AnalogClock;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Chronometer;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.DigitalClock;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;

public class MainActivity extends AppCompatActivity {
    Chronometer chronometer1;
    Button start,end;
    RadioButton nowTime,setTime,setDate;
    AnalogClock clock1;
    DigitalClock clock2;
    TimePicker viewTimePicker;
    CalendarView viewCalendar;
    TextView viewEndTime;
    String time="";
    String date="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewEndTime = findViewById(R.id.viewEndTime);
        chronometer1 = findViewById(R.id.chronometer1);
        start = findViewById(R.id.start);
        end = findViewById(R.id.end);
        nowTime = findViewById(R.id.nowTime);
        clock1 = findViewById(R.id.clock1);
        clock2 = findViewById(R.id.clock2);
        setTime = findViewById(R.id.setTime);
        viewTimePicker = findViewById(R.id.viewTimePicker);
        setDate = findViewById(R.id.setDate);
        viewCalendar = findViewById(R.id.viewCalendar);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chronometer1.setBase(SystemClock.elapsedRealtime());
                //예약시작클릭하면 타이머 시작
                chronometer1.start();;
                chronometer1.setTextColor(Color.RED);
            }
        });
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chronometer1.stop();
                //예약완료클릭하면 타이머 스톱
                chronometer1.setTextColor(Color.BLUE);
            }
        });

        nowTime.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    viewTimePicker.setVisibility(View.INVISIBLE);
                    viewCalendar.setVisibility(View.INVISIBLE);
                    //현재시간 라디오 버튼을 선택하면 디지털과 아날로그 시계를 보여 준다
                    clock1.setVisibility(View.VISIBLE);
                    clock2.setVisibility(View.VISIBLE);
                }
            }
        });

        setTime.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b) {
                    viewCalendar.setVisibility(View.INVISIBLE);
                    clock1.setVisibility(View.INVISIBLE);
                    clock2.setVisibility(View.INVISIBLE);
                    //시간 설정을 클릭하면 timePicker를 보여 준다
                    viewTimePicker.setVisibility(View.VISIBLE);
                }
            }
        });


        setDate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    viewTimePicker.setVisibility(View.INVISIBLE);
                    clock1.setVisibility(View.INVISIBLE);
                    clock2.setVisibility(View.INVISIBLE);
                    //날짜 설정을 클릭하면 Calendar를 보여 준다
                    viewCalendar.setVisibility(View.VISIBLE);
                }
            }
        });

        //timePicker로 지정한 시간을 textView에 보여 준다
        viewTimePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int i, int i1) {
                time = i + "시" + i1 + "분";
                viewEndTime.setText(date + "  " + time + "예약");
            }
        });

        //calendarView로 지정한 날짜를 textView에 보여 준다
        viewCalendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                date = i + "년"  + i1 + "월"  + i2 + "일";
                viewEndTime.setText(date + "  " + time + "예약");
            }
        });
    }
}
