package com.example.myservice;

//안드로이드 서비스 구현 방법
//1. 서비스를 구현할 클래스를 android.app 패키지의 Service 클래스를 상속 받고 Runnable 인터페이스를 구현받아 만든다
//   => 클래스이름에서 alt + enter 를 눌러 onBind() 메소드와 run() 메소드를 override 한다
//2, AndroidManifest.xml 파일의 <application> 태그 내부에 아래와 같이 실행할 서비스를 등록한다
//   => <service android:name=".MyService"/>
//3. 액티비티에서 startService() 메소드로 서비스를 실행한다
//   => startService() 메소드가 실행될 때 자동으로 실행되는 onStartCommand() 메소드를 override 시키고 서비스의 기능을 구현한다
//4. 액티비티에서 stopService() 메소드로 서비스를 종료한다
//   => stopService() 메소드가 실행될 때 자동으로 실행되는 onDestroy() 메소드를 override 시키고 서비스가 종료될 때 실행할 기능을 코딩한다
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class MyService extends Service implements Runnable{
    boolean flag = true;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void run() {
        //서비스 기능을 구현한다
        int count  = 0;
        while(count < 100){
            if(!flag){
                break;
            }
            Log.e("서비스 테스트", ++count + "번째 호출중");
            try{
                Thread.sleep(100);
            }catch(Exception e){}
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.e("서비스", "시작");
        //서비스 기능이 구현된 스레드를 실행한다
        Thread th = new Thread(new MyService());
        th.start();

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("서비스", "종료");
        flag = false;
    }
}

