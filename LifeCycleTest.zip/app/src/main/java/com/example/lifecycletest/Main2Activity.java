package com.example.lifecycletest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {
    EditText et1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        et1 = findViewById(R.id.et1);
        Log.e("LifeCycle", "Main2Activity onCreate() 실행");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("LifeCycle", "Main2Activity onPause() 실행");

        //데이터를 xml 파일로 안드로이드 기기에 저장한다 => 간단한 데이터 저장
        //안드로이드 앱이 종료되면 앱의 메모리에 있던 데이터가 사라지기 때문에 재 실행시 필요한 데이터라면
        //SharePreferences 인터페이스 객체를 사용해 안드로이드 단말기 내부에 xml 파일 형태로 key와 value가 쌍으로 구성되는 데이터를 저장할 수 있다
        //Device File Explorer에 파일을 확인할 수 있다

        //SharedPreferences의 Editor로 접근해서 데이터를 저장하고 SharedPreferences로 접근해서 데이터를 가져 온다
        //getSharedPreferences("xml 파일 이름", 저장방법)
        //MODE_PRIVATE => xml 파일을 새로 만들고 데이터를 저장한다.
        //MODE_APPEND => xml 파일이 존재할 경우 xml 파일에 데이터를 추가한다.
        //MODE_WORLD_READABLE => 다른 앱이 xml 파일을 읽을 수 있도록 허용한다.
        //MODE_WORLD_WRITEABLE => 다른 앱이 xml 파일에 쓸 수 있도록 허용한다.

        //LifeCycle.xml 파일을 새로 만들고 데이터를 저장할 수 있도록 준비한다
        SharedPreferences sharedPreferences = getSharedPreferences("LifeCycle",MODE_PRIVATE);
        //LifeCycle.xml 파일에 데이터를 저장할 수 있도록 Editor를 이용해 편집할 수 있는 상태로 만든다
        SharedPreferences.Editor editor = sharedPreferences.edit();
        //LifeCycle.xml 파일에 데이터를 넣어 준다 => 저장
        editor.putString("message","안드로이드");
        //LifeCycle.xml에 EditText에 입력한 데이터를 넣어 준다
        editor.putString("editText",et1.getText().toString());
        //LifeCycle.xml 파일을 저장한다 => commit

        editor.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("LifeCycle", "Main2Activity onResume() 실행");

        //LifeCycle.xml 파일에서 데이터를 읽어 와 복원한다
        SharedPreferences sharedPreferences = getSharedPreferences("LifeCycle",MODE_PRIVATE);
        //contains() : SharedPreferences 인터페이스 객체에 인수로 저장된 name이 있으면 true 없으며 false
        if(sharedPreferences != null && sharedPreferences.contains("editText")){
            et1.setText(sharedPreferences.getString("message","없어요"));
        }
    }

    public void goBack(View view) {
        finish();
    }

    public void goBack2(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("LifeCycle",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        //LifeCycle.xml파일의 editText라는 name을 지운다
        //실제로 name이 제거되는 것을 확인하려면 onPause(0 메소드를 주석으로 처리하면 화인가능
        editor.remove("editText");
        editor.remove("message");
        editor.commit();
        finish();
    }
}
