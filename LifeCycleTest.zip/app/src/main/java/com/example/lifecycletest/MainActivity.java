package com.example.lifecycletest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //onCreate() : 액티빝가 최초로 실행될 때 딱 1번 호출
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toast.makeText(getApplicationContext(),"MainActivity onCreate()",Toast.LENGTH_SHORT).show();
        //안드로이드 앱개발할 때 변수나 객체에 저장된 중간결과를 보고 싶을 떄 Log를 사용한다
        //Log 클래스는 Logcat에 메시지를 출력하는 안드로이드의 유틸리티 클래스이고 다음과 같은 메소드를 시용할 수 있다
        //v(String, String) : verbose
        //d(String, String) : debug
        //i(String, String) : information
        //w(String, String) : warning
       //e(String, String) : error
        Log.e("LifeCycle", "MainActivity onCreate() 실행");
    }

    //onStart() : 액티비티가 사용자에게 보여 지기 직전에 실행된다
    //액티비티가 최초로 실행될 떄 또는 다른 액티비티가 종료되서 현재 액티비티가 다시 화면에 나타날 때
    @Override
    protected void onStart() {
        super.onStart();
        Log.e("LifeCycle", "MainActivity onStart() 실행");
    }

    //onResume() : 액티비티가 사용자와 상호작용을 하기 직전에 실행된다
    @Override
    protected void onResume() {
        super.onResume();
        Log.e("LifeCycle", "MainActivity onResume() 실행");
    }

    //onPause() : 다른 액티비티가 실행되서 현재 액티비티를 가리기 시작하거나 현재 액티비티가 종료되기 시작하는 순간 실행된다
    @Override
    protected void onPause() {
        super.onPause();
        Log.e("LifeCycle", "MainActivity onPause() 실행");
    }

    //onStop() : 다른 액티비티가 실행되서 현재 액티비티를 완전히 가려서 더이상 보이지 않거나
    //현재 액티비티가 종료되서 더이상 화면에 보이지 않는 순간 실행된다
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("LifeCycle", "MainActivity onStop() 실행");
    }

    //onDestroy() : 프로그램이 완전히 종료될 때 딱 1번만 실행한다
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("LifeCycle", "MainActivity onDestroy() 실행");
    }

    //onRestart() ; 현재 액티비티가 중지(onStop())되고 난 루 다시 화면에 나타날 때 실행된다
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e("LifeCycle", "MainActivity onRestart() 실행");
    }

    public void viewActivity(View view) {
        Intent intent = new Intent(getApplicationContext(),Main2Activity.class);
        startActivity(intent);
    }
}
