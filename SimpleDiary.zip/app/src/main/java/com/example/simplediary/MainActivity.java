package com.example.simplediary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    DatePicker datePicker;
    Button write;
    EditText et;
    String filename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        datePicker = findViewById(R.id.datePicker);
        et = findViewById(R.id.et);
        write = findViewById(R.id.write);

        //Calendar 클래스를 이용해 현재 연.월.일을 구한 후에 데이트픽커 초기화
        //데이트픽커의 날짜가 변경되면 변경된 날짜에 해당하는 일기파일(연_월_일.txt)의 내용을 에디트텍스트에 보여줌
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int date = cal.get(Calendar.DATE);

        datePicker.init(year, month, date, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker datePicker, int i, int i1, int i2) {
                filename = Integer.toString(i) + "_" + Integer.toString(i1) + "_" + Integer.toString(i2 + 1) + "_" + Integer.toString(i2) + ".txt";
                String str = readDiary(filename);
                et.setText(str);
                write.setEnabled(true);
            }
        });

        //EditText에 입력한 내용을 파일에 쓴다
        write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    FileOutputStream outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                    String str = et.getText().toString();
                    outputStream.write(str.getBytes());
                    outputStream.close();
                    Toast.makeText(getApplicationContext(),filename + "이 저장됨",Toast.LENGTH_SHORT).show();
                } catch (Exception e) {  }
            }
        });
    }

    //현재 날짜 파일(연_월_일.txt)을 읽어 일기 내용을 반환하는 메소드
    public String readDiary(String filename) {
        String diaryStr = null;
        FileInputStream inputStream;

        try {
            inputStream = openFileInput(filename);
            byte[] txt = new byte[500];
            inputStream.read(txt);
            inputStream.close();
            diaryStr = (new String(txt)).trim();
            write.setText("수정하기");
        } catch (Exception e) {
            et.setHint("일기없음");
            write.setText("새로 저장");
        }
        return diaryStr;
    }
}
